#include <iostream>
#include "Box2D\Box2D.h"
#include "GL\freeglut.h"

class Box {
public:
	float x, y;
	float w, h;

	Box(float x_, float y_, b2World* world_) 
	{
		x = x_;
		y = y_;

		w = 2.0f;
		h = 2.0f;
		m_world = world_;

		// Step1 : define body
		b2BodyDef bd;
		bd.type = b2_dynamicBody;
		bd.position.Set(x, y);

		// Step2 : create body
		body = m_world->CreateBody(&bd);

		// Step3 : crate shape
		//b2PolygonShape ps;
		ps.SetAsBox(w, h);

		// Step4 : create Fixture
		b2FixtureDef fd;
		fd.shape = &ps;
		fd.density = 1.0f;
		fd.friction = 0.3f;
		fd.restitution = 0.5f;

		// Step5 : Attach shape to body with fixture
		body->CreateFixture(&fd);
	}

	void display()
	{
		b2Vec2 pos = body->GetPosition();
		float a = body->GetAngle();

		glMatrixMode(GL_MODELVIEW);

		glPushMatrix();
		glTranslatef(pos.x, pos.y, 0.0f);
		glRotatef(a, 0.0f, 0.0f, 1.0f);
		glColor3f(0.5f, 0.8f, 0.8f);

		glLineWidth(1.0f);
		glBegin(GL_QUADS);
		for (int i = 0; i < 4; i++) {
			glVertex2f(ps.m_vertices[i].x, ps.m_vertices[i].y);
		}
		glEnd();
		glPopMatrix();

	}
private:
	b2World* m_world;
	b2Body* body;
	b2PolygonShape ps;
	
};