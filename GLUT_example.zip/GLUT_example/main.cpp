#include <iostream>
#include "GL\freeglut.h"
#include "Box2D\Box2D.h"
#include "Box.cpp"
b2World* world;

int scr_width = 640;
int scr_height = 640;

float32 g_hz = 40.0f;
int32 velocityIterations = 8;
int32 positionIterations = 3;
float32 timeStep = 1.0f / g_hz;

Box* box1;

void Dokeyboard(unsigned char key, int x, int y)
{
	std::cout << "Input key : " << key << "\n" << std::endl;
	/*switch (key)
	{
	case 'w':
		prevBody[0]->ApplyLinearImpulseToCenter(b2Vec2(0.0f, 400.0f), true);
		break;
	case 'a':
		prevBody[0]->ApplyLinearImpulseToCenter(b2Vec2(-200.0f, 0.0f), true);
		break;
	case 'd':
		prevBody[0]->ApplyLinearImpulseToCenter(b2Vec2(200.0f, 0.0f), true);
		break;
	default:
		break;
	}*/
	glutPostRedisplay();
}

void Render()
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	gluOrtho2D(-25.0f, 25.0f, -5.0f, 25.0f);

	///Draw line test....
	//glPushMatrix();
	////glTranslatef(position.x, position.y, 0.0f);
	////glRotatef(angle, 0.0f, 0.0f, 1.0f);
	//glColor3f(0.8f, 0.8f, 0.8f);

	//glLineWidth(1.0f);
	//glBegin(GL_LINES);
	//glVertex2d(-25.0f, 0.0f);
	//glVertex2d(25.0f, 0.0f);
	//glEnd();
	//glPopMatrix();

	box1->display();

	glutSwapBuffers();
}

void Update(int value)
{
	world->Step(timeStep, velocityIterations, positionIterations);
	glutPostRedisplay();
	glutTimerFunc(20, Update, 0);
}

void Reshape(int _width, int _height)
{
	scr_width = _width;
	scr_height = _height;
	glViewport(0, 0, _width, _height);
}

void Setup()
{
	b2Vec2 gravity;
	gravity.Set(0.0f, -10.0f);
	
	world = new b2World(gravity);
	box1 = new Box(0.0f, 5.0f, world);

}

void Close()
{
	delete world;
	world = NULL;
}

int main(int argc, char** argv)
{
	glutInitWindowSize(scr_width, scr_height);
	glutInit(&argc, argv);
	glutCreateWindow("Box2D_example");

	Setup();

	glutKeyboardFunc(Dokeyboard);
	glutDisplayFunc(Render);
	glutReshapeFunc(Reshape);
	glutTimerFunc(20, Update, 0);
	glEnable(GL_DEPTH_TEST);

	glutMainLoop();
	return 0;
}